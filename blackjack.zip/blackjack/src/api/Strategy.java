package api;

public interface Strategy {
	public boolean hit();
	public void bet();
}
